import 'package:hooks_riverpod/hooks_riverpod.dart';

final catalog = StateProvider((ref) => 1);
